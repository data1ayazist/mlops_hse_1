from enum import Enum

class ModelType(str, Enum):
    SVC = "SVC"
    RandomForest = "RandomForest"